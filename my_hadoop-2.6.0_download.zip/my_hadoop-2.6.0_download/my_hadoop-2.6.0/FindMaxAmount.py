#!/usr/bin/env python

import sys

(prev_key, maxAmount) = (None, -0.001)

for line in sys.stdin:
	(key, amount) = line.split("\t")

	if key.find("PAYMENT") >= 0:
		continue
	elif prev_key and prev_key != key: 
		print prev_key + "\t" + str(maxAmount)
		(prev_key, amount)  = (key, float(amount))

	else:
		(prev_key, amount)  = (key, max (maxAmount, float(amount)))
if prev_key:
	print prev_key + "\t" + str(maxAmount)

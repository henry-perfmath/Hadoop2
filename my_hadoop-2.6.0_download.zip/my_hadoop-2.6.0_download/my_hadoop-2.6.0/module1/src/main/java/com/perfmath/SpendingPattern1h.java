import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.mapreduce.lib.chain.ChainMapper;
import org.apache.hadoop.mapreduce.lib.chain.ChainReducer;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.commons.cli.Options;

public class SpendingPattern1h {

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		String[] remainingArgs = new GenericOptionsParser(conf, args)
				.getRemainingArgs();
		// JobConf job = JobInit1.init (this, getConf (), args);
		if (args.length != 2) {
			// printUsage(tool, "<input> <output>");
			System.exit(-1);
		}
		Job job = Job.getInstance();
		job.setJarByClass(SpendingPattern1h.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		// if (job == null) {
		// // return -1;
		// }
		job.setJobName("Spending Pattern ChainMapper");
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		Configuration map0Conf = new Configuration(true);
		ChainMapper.addMapper(job, SpendingPatternMapper1b.class,
				LongWritable.class, Text.class, Text.class,
				FloatWritable.class, map0Conf);

		Configuration map1Conf = new Configuration(true);
		ChainMapper.addMapper(job, SpendingPatternMapper1c.class, Text.class,
				FloatWritable.class, Text.class, FloatWritable.class, map1Conf);
		Configuration reduceConf = new Configuration(true);
		ChainReducer.setReducer(job, SpendingPatternReducer1a.class,
				Text.class, FloatWritable.class, Text.class,
				FloatWritable.class, reduceConf);
		job.setReducerClass (SpendingPatternReducer1a.class);
		// job.setOutputKeyClass(Text.class);
		// job.setOutputValueClass(FloatWritable.class);

		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}

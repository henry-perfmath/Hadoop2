import java.io.IOException;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Mapper;

public class SpendingPatternMapper1c extends Mapper<Text, FloatWritable, Text, FloatWritable> {

	@Override
	public void map(Text key, FloatWritable value, Context context) throws IOException, InterruptedException{

		if (!key.toString().contains("PAYMENT")) {
			float amount = Float.parseFloat(value.toString());
			context.write (key, new FloatWritable(amount));
		} 
	}
}

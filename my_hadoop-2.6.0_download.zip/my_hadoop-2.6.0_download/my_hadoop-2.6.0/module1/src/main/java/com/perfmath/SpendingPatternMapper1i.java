import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SpendingPatternMapper1i extends Mapper<LongWritable, Text, Text, Text> {
 String recordToIgnore;
@Override
public void map(LongWritable key, Text value, Context context)
    throws IOException, InterruptedException {
	recordToIgnore = (context.getConfiguration()).get ("record.ignore.type", "PAYMENT");
  String line = value.toString();
  if (!line.contains (recordToIgnore)) {
  	StringTokenizer st = new StringTokenizer (line, "\t");
  	String tranxDate = st.nextToken();
  	String description = st.nextToken();
	String amount = st.nextToken ();
	context.write(new Text(description), new Text (amount));
  } else {
	context.getCounter(TxType.PAYMENT).increment(1);
  }
}

}

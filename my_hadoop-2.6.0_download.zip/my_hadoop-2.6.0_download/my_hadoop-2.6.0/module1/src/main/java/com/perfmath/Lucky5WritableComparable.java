import java.io.*;
import org.apache.hadoop.io.*;

public class Lucky5WritableComparable implements
		WritableComparable<Lucky5WritableComparable> {
	private int luckyNumber;
	private long timestamp;

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(luckyNumber);
		out.writeLong(timestamp);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		luckyNumber = in.readInt();
		timestamp = in.readLong();
	}

	@Override
	public int compareTo(Lucky5WritableComparable wc) {
		return (this.timestamp > wc.timestamp ? -1
				: (this.luckyNumber != wc.luckyNumber ? 0 : 1));
	}

	public static Lucky5WritableComparable read(DataInput in)
			throws IOException {
		Lucky5WritableComparable wc = new Lucky5WritableComparable();
		wc.readFields(in);
		return wc;
	}

	public String toString() {
		return "luckyNumber = " + luckyNumber + " timestamp = " + timestamp;
	}
}

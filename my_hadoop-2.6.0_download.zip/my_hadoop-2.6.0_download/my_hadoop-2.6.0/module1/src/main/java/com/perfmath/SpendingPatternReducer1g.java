import java.io.*;
import java.util.*;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class SpendingPatternReducer1g extends
		Reducer<Text, Text, NullWritable, Text> {
	private ArrayList <String> txFilter;
	private MultipleOutputs<NullWritable, Text> multipleOutputs;

	@Override
	protected void setup(Context context) throws IOException,
			InterruptedException {
		multipleOutputs = new MultipleOutputs<NullWritable, Text>(context);
		txFilter = new ArrayList<String>();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream("tx-type-filter.txt")));
			String line;
			while ((line = reader.readLine()) != null) {
				txFilter.add(line.trim());
			}
		} finally {
			if (reader!= null) reader.close();
		}
	}

	@Override
	public void reduce(Text key, Iterable<Text> values,
			Context context) throws IOException, InterruptedException {
		if (txTypeIsValid(key.toString())) {
			String fileName = generateFileNameForKeyValue(key);
			System.out.println(key + " fileName = " + fileName);
			if (fileName.contains("other")) {
				context.getCounter("City names not parsed properly ",
						key.toString()).increment(1);
			}
			float maxValue = Float.MIN_VALUE;
			for (Text value : values) {
				maxValue = Math.max(maxValue,
						Float.parseFloat(value.toString()));
			}
			String outValue = key.toString() + "\t" + Float.toString(maxValue);
			multipleOutputs.write(NullWritable.get(), new Text(outValue),
					fileName);
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException,
			InterruptedException {
		multipleOutputs.close();
	}

	protected String generateFileNameForKeyValue(Text key) {

		String city = key.toString().trim().substring(23);
	    if (!city.contains ("PAYMENT")) {
			if (Character.isLetter(city.charAt(0))) {
				int index = city.lastIndexOf(" ");
				String state = city.substring(index + 1);
				city = city.substring(0, index).trim() + "_" + state;
				return city.replaceAll(" ", "_") + "";
			} else {
				return "other";
			}
		} else {
			return "payment";
		}
	}

	protected boolean txTypeIsValid(String key) {
		boolean valid = true;
		for (int i = 0; i < txFilter.size(); i++) {
			if (key.startsWith(txFilter.get(i))) {
				valid = false;
				break;
			}
		}
		return valid;
	}
}
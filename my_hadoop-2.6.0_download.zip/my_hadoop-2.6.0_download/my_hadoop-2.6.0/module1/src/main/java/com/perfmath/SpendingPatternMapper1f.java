import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class SpendingPatternMapper1f
  extends Mapper<LongWritable, Text, NullWritable, Text> {
  private MultipleOutputs <NullWritable, Text> multipleOutputs;
  @Override
  protected void setup (Context context) throws IOException, InterruptedException {
	  multipleOutputs = new MultipleOutputs <NullWritable, Text> (context);
  }
  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
    
    String line = value.toString();
    if (!line.contains ("PAYMENT")) {
    	String fileName = generateFileNameForKeyValue (value);
    	multipleOutputs.write (NullWritable.get (), value, fileName);
    }
  }
  @Override
  protected void cleanup (Context context) throws IOException, InterruptedException {
	  multipleOutputs.close ();
  }
  protected String generateFileNameForKeyValue (Text value) {
	    
	    String line = value.toString();
	    if (!line.contains ("PAYMENT")) {
	    	String[] arr = line.split("\t", 0);
	    	String txDate = arr [0].replaceAll ("/", "");
	    	return txDate +"/part";
	    } else {
	    	return "payment/part";
	    }
}
}
import java.io.*;
import org.apache.hadoop.io.*;

public class Lucky5Writable implements Writable {
	private int luckyNumber;
	private long timestamp;

	public void write(DataOutput out) throws IOException {
		out.writeInt(luckyNumber);
		out.writeLong(timestamp);
	}

	public void readFields(DataInput in) throws IOException {
		luckyNumber = in.readInt();
		timestamp = in.readLong();
	}

	public static Lucky5Writable read(DataInput in) throws IOException {
		Lucky5Writable writable = new Lucky5Writable();
		writable.readFields(in);
		return writable;
	}
	public String toString () {
		return "luckyNumber = " + luckyNumber + 
				" timestamp = " + timestamp ;
	}
}

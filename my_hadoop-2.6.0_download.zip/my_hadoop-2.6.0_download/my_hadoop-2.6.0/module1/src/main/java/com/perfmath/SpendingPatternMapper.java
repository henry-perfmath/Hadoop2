import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SpendingPatternMapper
  extends Mapper<LongWritable, Text, Text, FloatWritable> {
  
  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
    
    String line = value.toString();
    if (!line.contains ("PAYMENT")) {
    	StringTokenizer st = new StringTokenizer (line, "\t");
    	String tranxDate = st.nextToken();
    	String description = st.nextToken();
    	float amount = Float.parseFloat(st.nextToken());
    	context.write(new Text(description), new FloatWritable(amount));
    }
  }
}

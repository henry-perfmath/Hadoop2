import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class SpendingPatternReducer1f
  extends Reducer<Text, Text, NullWritable, Text> {
  private MultipleOutputs <NullWritable, Text> multipleOutputs;
  @Override
  protected void setup (Context context) throws IOException, InterruptedException {
	  multipleOutputs = new MultipleOutputs <NullWritable, Text> (context);
  }
  @Override
  public void reduce(Text key, Iterable<Text> values, Context context)
      throws IOException, InterruptedException {

	  String fileName = generateFileNameForKeyValue (key);
	  System.out.println ("key=" + key + " fileName = " + fileName);
	  if (fileName.contains("other")) {
		  context.getCounter ("City names not parsed properly ", key.toString()).increment (1);
	  }
	float maxValue = Float.MIN_VALUE;
    for (Text value : values) { 	
    	maxValue = Math.max(maxValue, Float.parseFloat (value.toString()));   	
    }
    String outValue = key.toString () + "\t" + Float.toString (maxValue);
	multipleOutputs.write (NullWritable.get (), new Text (outValue), fileName);
  }
  @Override
  protected void cleanup (Context context) throws IOException, InterruptedException {
	  multipleOutputs.close ();
  }
  protected String generateFileNameForKeyValue (Text key) {
	   
	    String city = key.toString().trim().substring(23);
	    if (!city.contains ("PAYMENT")) {
	    	if (Character.isLetter(city.charAt (0))) {
	    		int index = city.lastIndexOf (" ");
	    		String state = city.substring(index + 1);
	    		city = city.substring(0, index).trim() + "_" + state;
	    		return city.replaceAll(" ", "_") + "";
	    	} else {
	    		return "other";
	    	}
	    } else {
	    	return "payment";
	    }
}
}